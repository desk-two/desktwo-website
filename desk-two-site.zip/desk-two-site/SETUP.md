# Desk Two: booking pop-up and welcome email

## What's in this folder

```
netlify.toml                      Tells Netlify where the site and function live
package.json                      Installs Nodemailer (the email library)
netlify/functions/send-welcome.js The function that sends both emails
public/index.html                 Your site, with the pop-up added
public/privacy.html               Privacy policy draft
public/img/                       Your logo (untouched) + a margin-cropped copy for email
```

Your existing `netlify.toml` published from a folder called `public`, so the site files now live there. Keep that structure.

---

## Step 1: Create the Google app password

The function logs in to team@desktwo.co.uk with an app password, a 16-character code that works only for this one job. Your real password is never used.

1. Sign in to Google as **team@desktwo.co.uk** and open **myaccount.google.com → Security**.
2. Make sure **2-Step Verification** is on. App passwords don't appear without it.
3. Search "App passwords" at the top of the page (Google moves this around), create one called `Desk Two website`, and copy the 16 characters. You only see them once.

If App passwords is missing, a Google Workspace admin may need to allow 2-Step Verification for the organisation (Admin console → Security → Authentication → 2-step verification). If it's still missing, tell me and we'll switch to a different sign-in method.

## Step 2: Get your booking link

Use any scheduler that gives you a public link: Google Calendar **Appointment schedules**, Calendly, Cal.com and so on. Open the link in a private browser window to check it works, then copy it. It must start with `https://`.

## Step 3: Add the environment variables in Netlify

Netlify → your site → **Site configuration → Environment variables → Add a variable**. Add all four:

| Key | Value |
|---|---|
| `GMAIL_USER` | `team@desktwo.co.uk` |
| `GMAIL_APP_PASSWORD` | the 16-character app password (spaces are fine) |
| `BOOKING_URL` | your booking link |
| `NOTIFY_EMAIL` | where visitor notifications go, e.g. `team@desktwo.co.uk` |

Tick "Contains secret values" for the password. **Redeploy after adding or changing variables**, because they only apply to new deploys.

## Step 4: Deploy

Drag-and-drop deploys **do not run functions**, so use one of these.

### Option A: GitHub (recommended)
1. Create a free account at github.com and make a **New repository** (private is fine).
2. Click **uploading an existing file**, drag in everything from this folder (including `netlify`, `public`, `package.json` and `netlify.toml`), and commit.
3. In Netlify, open your existing Desk Two site → **Site configuration → Build & deploy → Continuous deployment → Link repository** and choose the repo. (For a brand-new site: **Add new site → Import an existing project**.)
4. Build command: leave blank. Publish directory: `public`. Deploy.
5. Every future change you commit to GitHub deploys automatically.

### Option B: Netlify CLI
1. Install Node.js from nodejs.org, then in a terminal run `npm install -g netlify-cli`.
2. In this folder run `npm install`, then `netlify login`, then `netlify link` (pick your site).
3. Run `netlify deploy --prod`.

---

## Test checklist

- [ ] Nav "Book a call", hero "Book an Introductory Call" and the bottom button all open the pop-up
- [ ] Esc, the × and clicking the dark background all close it, and focus returns to the button you clicked
- [ ] Tab stays inside the pop-up; the focus outline is visible
- [ ] A bad email (`abc`) shows an error and doesn't send
- [ ] A real email shows the spinner, then "Check your inbox…"
- [ ] Welcome email arrives from **Desk Two <team@desktwo.co.uk>** with a working button and a plain-text version
- [ ] Hitting Reply goes to team@desktwo.co.uk
- [ ] The notification email arrives at `NOTIFY_EMAIL` with the visitor's address and time
- [ ] Try it on a phone, and with "reduce motion" switched on in your device settings
- [ ] Privacy link in the pop-up and footer opens `/privacy.html`
- [ ] Submit 6 times quickly: later attempts show the "too many requests" message (wait 10 minutes before testing again)
- [ ] Test with a Gmail, an Outlook and an iCloud address and check where each email lands

## Troubleshooting

**Email goes to spam.** Because the site sends through Google, check that the domain's DNS has Google's **SPF**, **DKIM** and **DMARC** records (Google Admin console → Apps → Google Workspace → Gmail → Authenticate email). If your DNS is managed by Netlify, the records must be added in Netlify's DNS panel, along with the Google **MX** records, or mail can fail altogether. Also ask early testers to mark the email "Not spam".

**"The form is not set up yet" (500).** One of the four variables is missing or `BOOKING_URL` doesn't start with `https://`. Fix it in Netlify, then redeploy. Netlify → **Logs → Functions → send-welcome** names the missing one.

**"We couldn't send your email" (502) and logs show `EAUTH` / `535`.** Wrong password or username. Create a fresh app password, make sure `GMAIL_USER` is exactly `team@desktwo.co.uk`, and redeploy.

**404 on `/.netlify/functions/send-welcome`.** The function didn't deploy. Check that it was deployed via GitHub or the CLI (not drag-and-drop), that the file is at `netlify/functions/send-welcome.js`, that `package.json` sits at the top level, and that the deploy log shows "Functions". Netlify → **Functions** tab should list it.

**"Too many requests" while testing.** Limits are 5 requests per IP per 10 minutes and 2 per email address per hour. Wait it out, or use another address.

**Pop-up doesn't open.** Hard-refresh the page. If it still fails, open the browser console and send me the red error.

## Notes

- **Nothing is stored.** The only record of a request is the notification email in your inbox. Function logs record errors but not email addresses.
- **Rate limiting is basic.** It lives in the function's memory and resets when Netlify restarts it. It stops casual abuse; the honeypot field catches most bots. If spam ever becomes a problem, add Cloudflare Turnstile.
- **Gmail sending limits** apply (about 2,000 emails a day on Workspace). Each request sends two emails, so you're fine at normal volumes.
- **Google Fonts** is loaded from Google's servers, which shares visitors' IP addresses with Google. The privacy page says so. Self-hosting the fonts later would remove that.
- **Privacy policy is a draft.** Please have it checked, and confirm the 12-month retention period matches what you really do. It doesn't cover newsletters; marketing emails would need a separate opt-in.
- **Email logo.** `desk-two-logo-email.png` is your logo with the empty margins trimmed so it fits an email. The artwork itself is unchanged and the original file is untouched.
